#ifndef LIBBASEDEFS_H_INC
#define LIBBASEDEFS_H_INC

#define _DSHOWLIB_NAMESPACE DShowLib
namespace DShowLib
{
};

namespace _DSHOWLIB_NAMESPACE	// define for certain code completion tools
{
};

#define UDSHL_NAME_BASE "TIS_UDSHL11"

#endif // LIBBASEDEFS_H_INC