// This file has been generated automatically using:
// "d:\jenkinsbuild\pylonwindows_releasebuild\workspace\build\filetemplates\pylonversionnumber.template.h"
// DO NOT EDIT!

#define PYLON_VERSION_MAJOR           5
#define PYLON_VERSION_MINOR           0
#define PYLON_VERSION_SUBMINOR        12
#define PYLON_VERSION_BUILD           11830
#define PYLON_VERSIONSTRING_MAJOR     "5"
#define PYLON_VERSIONSTRING_MINOR     "0"
#define PYLON_VERSIONSTRING_SUBMINOR  "12"
#define PYLON_VERSIONSTRING_BUILD     "11830"
#define PYLON_VERSIONSTRING_EXTENSION ""
